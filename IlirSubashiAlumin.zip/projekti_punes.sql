-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 04, 2024 at 05:15 PM
-- Server version: 10.4.25-MariaDB
-- PHP Version: 8.1.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projekti punes`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--
-- Error reading structure for table projekti punes.admin: #1932 - Table &#039;projekti punes.admin&#039; doesn&#039;t exist in engine
-- Error reading data for table projekti punes.admin: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `projekti punes`.`admin`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `cash`
--
-- Error reading structure for table projekti punes.cash: #1932 - Table &#039;projekti punes.cash&#039; doesn&#039;t exist in engine
-- Error reading data for table projekti punes.cash: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `projekti punes`.`cash`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `ekonomisti`
--
-- Error reading structure for table projekti punes.ekonomisti: #1932 - Table &#039;projekti punes.ekonomisti&#039; doesn&#039;t exist in engine
-- Error reading data for table projekti punes.ekonomisti: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `projekti punes`.`ekonomisti`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `klient`
--
-- Error reading structure for table projekti punes.klient: #1932 - Table &#039;projekti punes.klient&#039; doesn&#039;t exist in engine
-- Error reading data for table projekti punes.klient: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `projekti punes`.`klient`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `materialet`
--
-- Error reading structure for table projekti punes.materialet: #1932 - Table &#039;projekti punes.materialet&#039; doesn&#039;t exist in engine
-- Error reading data for table projekti punes.materialet: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `projekti punes`.`materialet`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `punetori`
--
-- Error reading structure for table projekti punes.punetori: #1932 - Table &#039;projekti punes.punetori&#039; doesn&#039;t exist in engine
-- Error reading data for table projekti punes.punetori: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `projekti punes`.`punetori`&#039; at line 1

-- --------------------------------------------------------

--
-- Table structure for table `shitje`
--
-- Error reading structure for table projekti punes.shitje: #1932 - Table &#039;projekti punes.shitje&#039; doesn&#039;t exist in engine
-- Error reading data for table projekti punes.shitje: #1064 - You have an error in your SQL syntax; check the manual that corresponds to your MariaDB server version for the right syntax to use near &#039;FROM `projekti punes`.`shitje`&#039; at line 1
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
